<?php


namespace App\Services\Implementations;


use App\libs\VkBot;
use App\Models\Birthday;
use App\Models\User;
use App\Repositories\Implementations\GroupRepository;
use App\Repositories\Implementations\UserRepository;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class BirthdayService
{
    private VkBot $bot;

    /**
     * BirthdayService constructor.
     */
    public function __construct () { $this->bot = new VkBot(new UserRepository(), new GroupRepository()); }

    public function notifyAboutBirthdays()
    {
        $current_date = date("Y-m-d");
         if ( Birthday::where([
                 [
                     "date",
                     $current_date
                 ]
             ])->count() > 0 )
             return false;

        $date_over_three_days = Carbon::now()->add(3, 'day')->format("m-d");
        $in_three_days_users = User::whereRaw("birthday LIKE '%{$date_over_three_days}'")->get();
        $this->bot->notifyAboutBirthdayInThreeDays($in_three_days_users);
        $today_date_formated_for_query = Carbon::now()->format("m-d");
        $today_users = User::whereRaw("birthday LIKE '%{$today_date_formated_for_query}'")->get();
        $this->bot->notifyAboutBirthdayToday($today_users);
        DB::table("birthdays_notifications")->insert(["date" => Carbon::now()->format("Y-m-d")]);
    }
}